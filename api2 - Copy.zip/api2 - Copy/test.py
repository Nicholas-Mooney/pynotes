import io
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", 'settings')
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'restaurants',
]
import django
import logging
import requests
django.setup()
import time
import logging
import random

from django.conf import settings
import django.db

# I know this is horrendous
# but before JSON PARSER can be imported it requires this setup in my project

from django.test import TestCase, Client
from django.urls import reverse
from restaurants.models import *
from rest_framework.parsers import JSONParser
from restaurants.serializers import RestaurantSerializer

GOOD_STATUS_RESPONSE = 200
VIEW_URL = 'http://localhost:8000/view_list'
ADD_URL = 'http://localhost:8000/restaurants/add'
EDIT_URL = 'http://localhost:8000/restaurant/edit/1'
DELETE_URL = 'http://localhost:8000/restaurants/delete/1'

class DataTest(TestCase):

    def setUp(self):
        logging.basicConfig(filename='restaurant_api_test.log', level=logging.INFO)
        logging.info('running setup')
        self.restaurant1 = Restaurant.objects.create(
            name="First",
            rating = 1,
            address = "Address1",
            street = "Street1",
            city = "City1",
            state = "S1",
            zip = 11111,
            review ="Review for restaurant 1",
            style = "Fast food"
        )
        self.restaurant2 = Restaurant.objects.create(
            name="Second",
            rating = 2,
            address = "Address2",
            street = "Street2",
            city = "City2",
            state = "S2",
            zip = 22222,
            review = "Review for restaurant 2",
            style = "Fast food"
        )
        self.test_client = Client("http://127.0.0.1:8000")
        self.restaurant1_json = {'CsrfViewMiddleware ': ['VZnkbf3KqCgG4ezhaG40LBGdZqJoH8BjHuyKqWCRNgOUZ9hUlOlklyU5KWrcZcQ7'],
                                 'name': ['First'],
                                 'rating': ['1'],
                                 'style': ['Fast food'],
                                 'address': ['Address1'],
                                 'street': ['Street1'],
                                 'city': ['City1'],
                                 'state': ['S1'],
                                 'zip': ['11111'],
                                 'review': ['Review for restaurant 1'],
                                 'Submit': ['Submit']}
        self.restaurant2_json = {'CsrfViewMiddleware ': ['VZnkbf3KqCgG4ezhaG40LBGdZqJoH8BjHuyKqWCRNgOUZ9hUlOlklyU5KWrcZcQ7'],
                                 'name': ['Second'],
                                 'rating': ['2'],
                                 'style': ['Fast food'],
                                 'address': ['Address2'],
                                 'street': ['Street2'],
                                 'city': ['City2'],
                                 'state': ['S2'],
                                 'zip': ['22222'],
                                 'review': ['Review for restaurant 2'],
                                 'Submit': ['Submit']}






    def test_restaurant(self):
        self.test_restaurant_api()
        restaurant_list = Restaurant.objects.all()
        restaurant = restaurant_list[0]
        logging.debug(restaurant_list)
        logging.debug(f'Inside test restaurant: restaurant is {restaurant}')
        self.assertEqual(restaurant.name, 'First')
        self.assertEqual(restaurant.rating, 1)
        self.assertEqual(restaurant.id, 1)

    def test_restaurant_api(self):
        restaurants_response = self.test_client.get(reverse('view_list'))
        logging.debug(f'TEST RESTAURANT API : api response is: {restaurants_response} and the status is {restaurants_response.status_code}')
        self.assertEqual(restaurants_response.status_code, 200)
        logging.debug(f'TEST RESTAURANT API : api response content is: {restaurants_response.content} and the status is {restaurants_response.status_code}')
        restaurants_stream = io.BytesIO(restaurants_response.content)
        logging.debug(f'\nTEST RESTAURANT API: api response stream is: {restaurants_stream} ')
        restaurant_data = JSONParser().parse(restaurants_stream)
        first_restaurant_data = restaurant_data[0]
        logging.debug(f'\nTEST RESTAURANT API: api response data is: {first_restaurant_data} and its id is {first_restaurant_data["id"]}')
        # Now go directly to the DB to get the same object
        first_restaurant_db = Restaurant.objects.get(id=first_restaurant_data['id'])
        logging.debug(f'\nTEST RESTAURANT API: api response restaurant object from DB is: {first_restaurant_db}')
        # Now create an object from the dictionary we got from the API
        first_restaurant_serializer = RestaurantSerializer(first_restaurant_db, data=first_restaurant_data)
        logging.debug(f'\nTEST RESTAURANT API: api response restaurant serializer  is: {first_restaurant_serializer}')
        logging.debug(f'\nTEST RESTAURANT API: api response restaurant serializer validity is: {first_restaurant_serializer.is_valid()}')
        logging.debug(f'\nTEST RESTAURANT API: api response restaurant serializer valid data is: {first_restaurant_serializer.validated_data}')
        first_restaurant_api = first_restaurant_serializer.save()
        logging.debug(f'\nTEST RESTAURANT API: api response restaurant api object is : {first_restaurant_api}')
        self.assertEqual(first_restaurant_db, first_restaurant_api)

    def test_api_list(self):
        logging.info('checking _list')
        restaurants_response_list = requests.get(VIEW_URL)
        self.assertEqual(restaurants_response_list.status_code, GOOD_STATUS_RESPONSE)
        pass

    def test_api_add(self):
        params = self.restaurant1_json
        logging.debug('adding')
        logging.info(params)

        restaurants_response_add = db_retry(add, params, timeout=30)
        #restaurants_response_add = requests.post(ADD_URL, params)
        #logging.debug(restaurants_response_add.status_code)
        self.assertEqual(restaurants_response_add.status_code, GOOD_STATUS_RESPONSE)

        logging.info('checking _list')
        #restaurants_response_list = requests.get(VIEW_URL)
        #logging.debug(restaurants_response_list.json())
        #self.assertEqual(restaurants_response_list.json()[0]['name'], self.restaurant1_json['name'])
        pass

    def test_api_edit(self):
        logging.info('adding')
        params = self.restaurant1_json
        logging.debug(params)
        restaurants_response_add = requests.post(ADD_URL, params)
        logging.debug(restaurants_response_add.status_code)
        self.assertEqual(restaurants_response_add.status_code, GOOD_STATUS_RESPONSE)
        logging.info('checking _list')
        restaurants_response_list = requests.get(VIEW_URL)
        logging.debug(restaurants_response_list.json())
        self.assertEqual(restaurants_response_list.json()[0]['name'], self.restaurant1_json['name'])
        logging.info('editing')
        params = self.restaurant2_json
        logging.debug(params)
        restaurants_response_edit = requests.post(EDIT_URL)
        logging.debug(restaurants_response_edit.status_code)
        self.assertEqual(restaurants_response_edit.status_code, GOOD_STATUS_RESPONSE)
        logging.info('checking _list')
        restaurants_response_list = requests.get(VIEW_URL)
        logging.debug(restaurants_response_list.json())
        self.assertEqual(restaurants_response_list.json()[0]['name'], self.restaurant2_json['name'])
        pass

    def test_api_delete(self):
        logging.info('adding')
        params = self.restaurant1_json
        logging.debug(params)
        restaurants_response_add = requests.post(ADD_URL, params)
        logging.debug(restaurants_response_add.status_code)
        self.assertEqual(restaurants_response_add.status_code, GOOD_STATUS_RESPONSE)
        logging.info('checking _list')
        restaurants_response_list = requests.get(VIEW_URL)
        logging.debug(restaurants_response_list.json())
        self.assertEqual(restaurants_response_list.json()[0]['name'], self.restaurant1_json['name'])
        length_before_delete = len(restaurants_response_list.json())
        logging.info('deleting')
        restaurants_response_delete = requests.post(DELETE_URL)
        logging.debug(restaurants_response_delete.status_code)
        self.assertEqual(restaurants_response_delete.status_code, GOOD_STATUS_RESPONSE)
        logging.info('checking _list')
        restaurants_response_list = requests.get(VIEW_URL)
        logging.debug(restaurants_response_list.json())
        self.assertEqual(restaurants_response_list.status_code, GOOD_STATUS_RESPONSE)
        length_after_delete = len(restaurants_response_list.json())
        self.assertEqual(length_before_delete, length_after_delete + 1)
        pass

class SimpleTest(TestCase):
    @classmethod
    def setUp(self):
        self.test_client = Client()

    def test_response(self):
        response = self.test_client.get(reverse('index'))
        logging.info(f'In simple test, response is {response}')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content, b'Hello world, from Dan')

def db_retry(fn, params, timeout=None):
    """Call fn with no arguments. If OperationalError exception, make retries until timeout has passed"""
    timeout = timeout or settings.DATABASES['default'].get('OPTIONS', dict()).get('timeout', 5)
    now = time.time()
    give_up_time = now + timeout
    retries = 0
    while now < give_up_time:
        now = time.time()
        try:
            result = fn(params)
            if retries:
                logger.warning(f'db_retry: Succeeded after {retries} retries')
            return result
        except django.db.OperationalError as exception:
            msg = str(exception)
            if 'locked' in msg:  # pragma: no cover
                retries += 1
                wait_time = random.uniform(1, timeout / 10)
                logger.warning(f'db_retry: {msg}: Retrying after {wait_time} seconds')
                django.db.close_old_connections()
                time.sleep(wait_time)
            else:  # pragma: no cover
                logger.exception(f'db_retry: {msg}: Giving up')
                raise


def add(params):
    restaurant1_json = {'CsrfViewMiddleware ': ['VZnkbf3KqCgG4ezhaG40LBGdZqJoH8BjHuyKqWCRNgOUZ9hUlOlklyU5KWrcZcQ7'],
                             'name': ['First'],
                             'rating': ['1'],
                             'style': ['Fast food'],
                             'address': ['Address1'],
                             'street': ['Street1'],
                             'city': ['City1'],
                             'state': ['S1'],
                             'zip': ['11111'],
                             'review': ['Review for restaurant 1'],
                             'Submit': ['Submit']}
    #params = restaurant1_json
    return requests.post(ADD_URL, params)
