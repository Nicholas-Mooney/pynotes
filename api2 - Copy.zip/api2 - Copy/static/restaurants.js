// Comment
function addRestaurant() {
    console.log("Get the blank form from the server.");
    const url = "http://localhost:8000/restaurants/add";
    window.open(url, "_self");
}

function homePage() {
    console.log('getting the main (home) page - calling the list handler');
    const url = "http://localhost:8000/view_list";
    window.open(url, "_self");
}

function editRestaurant() {
    console.log("Get the edit page from the server.");
    const url = `http://localhost:8000/restaurant/edit/${document.getElementById('restaurant_select').value}`;
    window.open(url, "_self");
}

function formValidate() {
    zip_element = document.getElementById('zip_edit');
    zip_value = zip_element.value;
    zip_number = parseInt(zip_value);
    if (zip_value.length() != 5) {
        alert('Zip value is not the correct length. Please use exactly 5 digits.');
        return false;
    }
    return true;
}

function deleteRestaurant() {
    console.log("Deleting Restaurant.");
    var selectElement = document.getElementById('restaurant_select');
    if (confirm(`Are you sure you want to delete Restaurant ${selectElement.options[selectElement.selectedIndex].text}`))
    {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            console.log(this.responseText);
            if (this.readyState == 4 && (this.status >= 200 && this.status < 300)) {
                console.log(`deleted instance successfully`);
                window.location = "http://localhost:8000/view_list";
            } else {
                console.log(`failed to delete Restaurant instance`);
                window.location = "http://localhost:8000/view_list";
            }
        }
        xhttp.open("POST", `http://localhost:8000/restaurants/delete/${selectElement.value}`, true);
        var csrfToken = myCookie('csrftoken');
        xhttp.setRequestHeader("X-CSRFToken", csrfToken);
        xhttp.setRequestHeader("Content_Type", "application/x-www-form-urlencoded");
        xhttp.send();
    }
}

function myCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}