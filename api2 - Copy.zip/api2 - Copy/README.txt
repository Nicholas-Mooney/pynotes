#command to run : python manage.py runserver
#command to startup table creation: python manage.py migrate