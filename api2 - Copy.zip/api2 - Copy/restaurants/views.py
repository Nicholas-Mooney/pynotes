from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from rest_framework import generics
from restaurants.models import Restaurant
from restaurants.models import RestaurantForm
from restaurants.serializers import RestaurantSerializer
from django.views.decorators.csrf import csrf_exempt
#adding csrf exempt because i dont expect any cross site request forgery

class RestaurantList(generics.ListCreateAPIView):
    queryset = Restaurant.objects.all()
    serializer_class = RestaurantSerializer

def index(request):
    return HttpResponse('Hello world, from Dan')

def home(request):
    restaurant_list = Restaurant.objects.all()
    return render(request, 'static/home.html',context={'restaurant_list': restaurant_list})

@csrf_exempt
def add_restaurant(request):
    restaurant_list = Restaurant.objects.all()
    print(request)
    if request.method =='GET':
        restaurant_list = Restaurant.objects.all()
    else:
        curr_id = request.POST.get('id')
        print(request.POST)
        new_restaurant = RestaurantForm(request.POST)
        if new_restaurant.is_valid():
            new_restaurant.save()
        else:
            new_restaurant.clean() #potential error in this location due to un cleanable data
            new_restaurant.save()
    return render(request=request, template_name='static/add.html', context={'restaurant_list': restaurant_list})

@csrf_exempt
def delete_restaurant(request, cur_id=None):
    print(cur_id)
    print('delete')
    if(cur_id >= 1):
        restaurant_to_delete = Restaurant.objects.get(id=cur_id)
        restaurant_to_delete.delete()
    return redirect('/restaurants/list')

@csrf_exempt
def view_list(request):
    print('awd')
    restaurant_list = Restaurant.objects.all()
    serializer = RestaurantSerializer(restaurant_list, many=True)
    #    restaurant = Restaurant.objects.get(id=44)
    print(restaurant_list)
    for restaurant in restaurant_list:
        print(f'Restaurant: {restaurant.name} - rating: {restaurant.rating}')
    return JsonResponse(serializer.data, safe=False)

@csrf_exempt
def edit_restaurant(request, cur_id=0):
    if cur_id == 0:
        return redirect('get_restaurants')
    if request.method == 'GET':
        restaurant_list = Restaurant.objects.all()
        cur_restaurant = Restaurant.objects.get(id=cur_id)
        return render(request, 'static/edit.html', {'restaurant_list': restaurant_list, 'cur_restaurant': cur_restaurant} )
    else:
        restaurant_to_edit = Restaurant.objects.get(id=cur_id)
        restaurant_form = RestaurantForm(request.POST, instance=restaurant_to_edit)
        restaurant_form.save()
    return redirect('/restaurants/list')


