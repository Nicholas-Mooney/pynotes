from django.core import serializers
from rest_framework import serializers
from restaurants.models import Restaurant

class RestaurantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Restaurant
        fields = ['id', 'name', 'rating', 'address', 'street', 'city', 'state', 'zip', 'review', 'style']

    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField()
    address = serializers.CharField()
    street = serializers.CharField()
    city = serializers.CharField()
    state = serializers.CharField()
    zip = serializers.IntegerField()
    review = serializers.CharField()
    style = serializers.CharField()
