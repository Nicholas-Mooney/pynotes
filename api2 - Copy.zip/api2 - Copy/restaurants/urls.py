from django.urls import path
import restaurants.views as views

app_name = 'restaurants'

# adding, receiving, editing, removing + index_response and home_page
urlpatterns = [
    path('', views.index, name='index'),
    path('home', views.home, name='home'),
    path('restaurants/add', views.add_restaurant, name='add_restaurant'),
    path('restaurants/delete/<int:cur_id>', views.delete_restaurant, name='delete_restaurant'),
    path('restaurant/edit/<int:cur_id>', views.edit_restaurant, name='edit_restaurant'),
    path('view_list', views.view_list, name='view_list'),
]