from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.forms import CharField, IntegerField, ModelForm


class Restaurant(models.Model):
    name = models.CharField(max_length=100)
    rating = models.IntegerField()
    address = models.CharField(max_length=50, null=True)
    street = models.CharField(max_length=50, null = True)
    city = models.CharField(max_length=50, null=True)
    state = models.CharField(null=True, max_length=2)
    zip = models.IntegerField()
    review = models.CharField(max_length=3000)
    style = models.CharField(max_length=50)
    create_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)


class RestaurantForm(ModelForm):
    class Meta:
        model = Restaurant
        fields = ['name', 'rating', 'address', 'street', 'city', 'state', 'zip', 'review', 'style']


