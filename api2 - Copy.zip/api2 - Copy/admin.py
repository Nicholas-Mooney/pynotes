from django.contrib import admin
from restaurants.models import Restaurant

admin.site.register(Restaurant)

